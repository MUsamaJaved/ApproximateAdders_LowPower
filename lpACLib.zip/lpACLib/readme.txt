This Directory Contains two Folders.

1. HW
   ---> This Directory contains the VHDL sources for all modules.
   --->See "readme.txt" file in this folder for further details on the designs.
   
2. SW
   ---> This Directory contains the C and MATLAB source-code for the corresponding behavioural models.
   --->See "readme.txt" file in this folder for further details on the implementations.

* For questions please email Dr. Muhammad Shafique (swahlah@yahoo.com) and Walaa El-Harouni (walaa.elharouny@gmail.com)

* Contributors
1. Muhammad Shafique
2. Rehan Hafiz
3. Semeen Rehman
4. Walaa El-Harouni
5. J�rg Henkel
6. Vanshika Baoni
7. Muhammad Abdullah Hanif