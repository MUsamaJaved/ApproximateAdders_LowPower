* “ApproxArithLib” is the final implementation. 

* The Directory contains two sub-folders

1. The folder “ApproxArithLib_C” represents the complete project for compilation, while the sub-folders contain the behavioral implementation in C for the corresponding design, i.e. adder, multiplier, or accelerator.

* The statistics for error calculation are implemented in  "statistics.c"

2. The folder “ApproxArithLib_MATLAB”provides the behavioral implementation in MATLAB for the corresponding designs.

* For questions please email Dr. Muhammad Shafique (swahlah@yahoo.com) and Walaa El-Harouni (walaa.elharouny@gmail.com)
