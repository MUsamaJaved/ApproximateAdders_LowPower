* This directory contains two folders 'adder' and 'multiplier'

* Each of the folder contains the MATLAB codes for the implementation of the approximate adders and multipliers respectively 

* For questions please email Dr. Muhammad Shafique (swahlah@yahoo.com) and Vanshika Baoni (vbaoni@gmail.com)