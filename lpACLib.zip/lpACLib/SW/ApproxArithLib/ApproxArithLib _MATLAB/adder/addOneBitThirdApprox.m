% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: addOneBitThirdApprox.m
%   a first operand (one bit 0/1)
%   b second operand (one bit 0/1)
%   cin carry-in
%   sum 1 bit output
%   cout 1 bit carry
function [sum,cout]= addOneBitThirdApprox(a,b,cin)
    cout=a;
    sum=b;
end