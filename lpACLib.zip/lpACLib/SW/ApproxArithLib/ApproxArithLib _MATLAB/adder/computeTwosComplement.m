% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: computeTwosComplement.m
% size the size of the binary array
% binary the binary array to be converted (in the form of an array of size 'size')
% twosComplement the two's complement representation of the binary number (in the form of an array of size 'size')
function twosComplement=computeTwosComplement(binary,size)
    one=zeros(1,size);
    inverted=zeros(1,size);
    one(1,size)=1;
    for i=1:1:size
        inverted(1,i)=1-binary(1,i);
    end
    [twosComplement,cout]=addMultiBitAccurate(inverted,one,0,size);
end
