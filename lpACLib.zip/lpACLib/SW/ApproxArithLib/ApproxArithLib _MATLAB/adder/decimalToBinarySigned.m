% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: decimalToBinarySigned.m
% decimal the decimal number to be converted
% size the required size of the resulting binary array
% binary a binary array (in the form of an array of size 'size')
function binary=decimalToBinarySigned(decimal,size)
    if decimal>=0
        binary=decimalToBinaryUnsigned(decimal,size);
    else
        magnitude=decimal*(-1);
        toComplement=decimalToBinaryUnsigned(magnitude,size);
        binary=computeTwosComplement(toComplement,size);
    end
end