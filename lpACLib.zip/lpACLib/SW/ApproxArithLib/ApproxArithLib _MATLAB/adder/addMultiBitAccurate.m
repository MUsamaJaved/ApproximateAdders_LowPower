% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: addMultiBitAccurate.m
% a                 first operand (in the form of an array)
% b                 second operand (in the form of an array)
% cin               carry-in (0/1)
% sum               resulting sum (in the form of an array of size 'totalBitNum')
% cout              resulting cout (0/1)
% totalBitNum		the number of bits for the multi-bit adder to be simulated
function [sum,cout]=addMultiBitAccurate(a,b,cin,totalBitNum)
    sum=zeros(1,totalBitNum);
    carryInternal=zeros(1,totalBitNum+1);
    carryInternal(1,totalBitNum+1)=cin;
 
    for i=totalBitNum:-1:1
        [sum(1,i),carryInternal(1,i)]=addOneBitAccurate(a(1,i),b(1,i),carryInternal(1,i+1));
    end
    cout=carryInternal(1,1);
end