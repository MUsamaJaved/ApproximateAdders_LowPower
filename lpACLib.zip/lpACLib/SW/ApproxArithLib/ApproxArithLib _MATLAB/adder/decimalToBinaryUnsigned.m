% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: decimalToBinaryUnsigned.m
% decimal the decimal number to be converted 
% size the required size of the resulting binary array
% binary a binary array (in the form of an array of size 'size')
function binary=decimalToBinaryUnsigned(decimal,size)
    index=size;
    binary=zeros(1,size);
    while decimal~=0
        r=rem(decimal,2);
        decimal=floor(decimal/2);
        binary(1,index)=r;
        index=index-1;
    end
end