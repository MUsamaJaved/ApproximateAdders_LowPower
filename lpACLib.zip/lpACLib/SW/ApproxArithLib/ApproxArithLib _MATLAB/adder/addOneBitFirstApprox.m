% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: addOneBitFirstApprox.m
%   a first operand (one bit 0/1)
%   b second operand (one bit 0/1)
%   cin carry-in
%   sum 1 bit output
%   cout 1 bit carry
function [sum,cout]= addOneBitFirstApprox(a,b,cin)
    cout=0;
    if (b==1 || (a==1 && cin==1))==1
        cout=1;
    end
    sum=1-cout;
end