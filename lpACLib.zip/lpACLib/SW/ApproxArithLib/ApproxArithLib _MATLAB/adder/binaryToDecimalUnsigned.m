% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: binaryToDecimalUnsigned.m
% size the size of the binary array
% binary the binary array to be converted (in the form of an array of size 'size')
% decimal the resulting decimal number 
function decimal=binaryToDecimalUnsigned(binary,size)
    decimal=0;
    lastIndex=size;
    for i=1:1:size
        decimal=decimal+binary(1,i)*(2^(lastIndex-i));
    end
end