% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: add.m
% x first operand (in decimal)
% y second operand (in decimal)
% cin carry-in (0/1)
% cout resulting cout
% adder adder-type
% totalBitNum the number of bits for the multi-bit adder to be simulated
% approxBitNum the number of approximate LSBs for the multi-bit adder to be simulated
% totalBitNum should include an additional two bits; one for the carry and the other for the sign

function [decimalSum]=add(x,y,cin,cout,adder,totalBitNum,approxBitNum)
    if strcmp(adder,'C_ADD')==1
        decimalSum=x+y;
        cout=0;
    else
        binaryX=decimalToBinarySigned(x,totalBitNum);
        binaryY=decimalToBinarySigned(y,totalBitNum);
        switch (adder)
            case 'IMPACT_ZERO'
                [sum,cout]=addMultiBitZeroApprox(binaryX, binaryY, cin,  totalBitNum, approxBitNum);
            case 'IMPACT_FIRST'
                [sum,cout]=addMultiBitFirstApprox(binaryX, binaryY, cin, totalBitNum, approxBitNum);
            case 'IMPACT_THIRD'
                [sum,cout]=addMultiBitThirdApprox(binaryX, binaryY, cin, totalBitNum, approxBitNum);
            case 'ACCURATE_ADD'
                [sum,cout]=addMultiBitAccurate(binaryX, binaryY, cin, totalBitNum);
            otherwise;
                [sum,cout]=addMultiBitAccurate(binaryX, binaryY, cin, totalBitNum);
        end
        decimalSum = binaryToDecimalSigned(sum, totalBitNum);
    end
end