% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: addMultiBitZeroApprox.m
% This function implements IMPACT_ZERO ADDER
% a                 first operand (in the form of an array)
% b                 second operand (in the form of an array)
% cin               carry-in 
% sum               resulting sum (in the form of an array of size 'totalBitNum')
% cout              resulting cout
% totalBitNum		the number of bits for the multi-bit adder to be simulated
% approxBitNum		the number of approx. LSBs for the multi-bit adder to be simulated
function [sum,cout]=addMultiBitZeroApprox(a,b,cin,totalBitNum,approxBitNum)
    sum=zeros(1,totalBitNum);
    carryInternal=zeros(1,totalBitNum+1);
    accurateStart=totalBitNum-approxBitNum;
    carryInternal(1,totalBitNum+1)=cin;
    for i=totalBitNum:-1:accurateStart+1
        [sum(1,i),carryInternal(1,i)]=addOneBitZeroApprox(a(1,i),b(1,i),carryInternal(1,i+1));
    end
    for i=accurateStart:-1:1
        [sum(1,i),carryInternal(1,i)]=addOneBitAccurate(a(1,i),b(1,i),carryInternal(1,i+1));
    end
    cout=carryInternal(1,1);
end