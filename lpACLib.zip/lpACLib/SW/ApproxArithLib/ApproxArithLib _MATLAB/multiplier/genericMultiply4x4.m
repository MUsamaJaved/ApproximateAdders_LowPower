% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: genericMultiply4x4.m
%   first  	first operand (decimal)
%   second	second operand (decimal)
%   multiplier 	an array of 4 multipliers specifying the multiplier for each of the 2x2 multipliers needed
%   adder		the adder-type to use when summing the partial products
%   approxBits  the number of approx. LSBs to apply when adding (maximum is 8)
%   result 		the product of the two operands
function product=genericMultiply4x4(first,second,multiplier,adder,approxBits)
    totalBitNum=8+2;
    carry=0;
    temp=getBlocksof2(first);
    aH=temp(1,1);
    aL=temp(1,2);
    temp=getBlocksof2(second);
    xH=temp(1,1);
    xL=temp(1,2);
    row1 = genericMultiply2x2(aL, xL, multiplier(1,1));
	row2 = genericMultiply2x2(aH, xL, multiplier(1,2));
	row3 = genericMultiply2x2(aL, xH, multiplier(1,3));
	row4 = genericMultiply2x2(aH, xH, multiplier(1,4));
    product = add (row1   , row2 * 4  , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 4  , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 16 , carry,  carry, adder, totalBitNum, approxBits);
end
