% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getRangesFor8x8.m
% number a number (representable by 8 bits in binary) to be split into 2 numbers
% ranges an array values representing the block ranges
function ranges=getRangesFor8x8()
    elements=17;
    ranges=zeros(1,elements);
    value=0;
    for i=1:1:elements
        ranges(1,i)=value;
        value=value+16;
    end
end