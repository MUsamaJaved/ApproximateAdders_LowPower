% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: genericMultiply8x8.m
%   first         first operand (decimal)
%   second        second operand (decimal)
%   multiplier 	an array of 16 multipliers specifying the multiplier for each of the 2x2 multipliers needed
%   adder         the adder-type to use when summing the partial products
%   approxBits    the number of approx. LSBs to apply when adding (maximum is 10)
%   result 		the product of the two operands
function product=genericMultiply8x8(first,second,multiplier,adder,approxBits)
    totalBitNum=16+2;
    carry=0;
    firstSign=1;
    secondSign=1;
    if first<0
        first=first*(-1);
        firstSign=-1;
    end
    if second<0
        second=second*(-1);
        secondSign=-1;
    end
    ranges8x8 = getRangesFor8x8();
	temp = getBlocksof4WithRanges(first, ranges8x8);
	aH = temp(1,1);
	aL = temp(1,2);

	temp = getBlocksof4WithRanges(second, ranges8x8);
	xH = temp(1,1);
	xL = temp(1,2);

	
	row1 = genericMultiply4x4(aL, xL, multiplier(1,1:4), adder, approxBits);
	row2 = genericMultiply4x4(aH, xL, multiplier(1,5:8), adder, approxBits); 
	row3 = genericMultiply4x4(aL, xH, multiplier(1,9:12), adder, approxBits); 
	row4 = genericMultiply4x4(aH, xH, multiplier(1,13:16), adder, approxBits);

	product = add (row1   , row2 * 16 , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 16 , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 256, carry,  carry, adder, totalBitNum, approxBits);
    product=product * firstSign * secondSign;
        
end