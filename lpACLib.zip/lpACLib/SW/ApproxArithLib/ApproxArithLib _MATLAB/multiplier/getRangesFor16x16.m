% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getRangesFor16x16.m
% number a number (representable by 16 bits bits in binary) to be split into 2 numbers
% ranges an array values representing the block ranges
function ranges=getRangesFor16x16()
    elements=257;
    ranges=zeros(1,elements);
    value=0;
    for i=1:1:elements
        ranges(1,i)=value;
        value=value+256;
    end
end