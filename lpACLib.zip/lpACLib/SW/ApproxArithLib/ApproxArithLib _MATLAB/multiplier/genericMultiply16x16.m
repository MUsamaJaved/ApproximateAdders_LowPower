% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: genericMultiply16x16.m
% first         first operand (decimal)
% second        second operand (decimal)
% multiplier 	an array of 64 multipliers specifying the multiplier for each of the 2x2 multipliers needed
% adder         the adder-type to use when summing the partial products
% approxBits    the number of approx. LSBs to apply when adding (maximum is 10)
% result 		the product of the two operands
function product=genericMultiply16x16(first,second,multiplier,adder,approxBits)
    totalBitNum=32+2;
    carry=0;
    maxNum=2^16;
    firstSign=1;
    secondSign=1;
    if first < 0
        firstSign = -1;
		first = first + maxNum;
    end
	if second<0
        secondSign=-1;
        second=second+maxNum;
    end
	ranges8x8 = getRangesFor8x8();
	ranges16x16 = getRangesFor16x16();

	temp = getBlocksof8(first, ranges16x16);
	aH = temp(1,1);
	aL = temp(1,2);

	temp = getBlocksof8(second, ranges16x16);
	xH = temp(1,1);
	xL = temp(1,2);

	row1 = genericMultiply8x8(aL, xL, multiplier(1,1:16), adder, approxBits); 
	row2 = genericMultiply8x8(aH, xL, multiplier(1,17:32), adder, approxBits); 
	row3 = genericMultiply8x8(aL, xH, multiplier(1,33:48), adder, approxBits); 
	row4 = genericMultiply8x8(aH, xH, multiplier(1,49:64), adder, approxBits); 

	product = add (row1   , row2 * 256  , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 256  , carry,  carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 65536, carry,  carry, adder, totalBitNum, approxBits);

    binSigned = decimalToBinarySigned(product, totalBitNum);

    binProduct = binSigned(1,19:totalBitNum);
    product =  binaryToDecimalUnsigned(binProduct, 16);

    if firstSign ~= secondSign
    	product = product - 2^16 ;
    end
end