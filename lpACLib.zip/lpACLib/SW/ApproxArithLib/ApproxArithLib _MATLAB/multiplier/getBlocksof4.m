% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getBlocksof4.m
% number a number (representable by 8 bits in binary) to be split into 2 numbers
% blocks an array of two numbers, each representable by 4 bits in binary
function blocks=getBlocksof4(number)
    if number < 16 
		blocks(1,1) = 0;
		blocks(1,2) = number;
    elseif (number >= 16) && (number < 32) 
		blocks(1,1) = 1;
		blocks(1,2) = number - 16;
    elseif (number >= 32) && (number < 48)
		blocks(1,1) = 2;
		blocks(1,2) = number - 32;
	elseif (number >= 48) && (number < 64) 
		blocks(1,1) = 3;
		blocks(1,2) = number - 48;
	elseif (number >= 64) && (number < 80)
		blocks(1,1) = 4;
		blocks(1,2) = number - 64;
	elseif (number >= 80) && (number < 96) 
		blocks(1,1) = 5;
		blocks(1,2) = number - 80;
    elseif (number >= 96) && (number < 112) 
		blocks(1,1) = 6;
		blocks(1,2) = number - 96;
	elseif (number >= 112) && (number < 128) 
		blocks(1,1) = 7;
		blocks(1,2) = number - 112;
	elseif (number >= 128) && (number < 144) 
		blocks(1,1) = 8;
		blocks(1,2) = number - 128;
    elseif (number >= 144) && (number < 160) 
		blocks(1,1) = 9;
		blocks(1,2) = number - 144;
	elseif (number >= 160) && (number < 176) 
		blocks(1,1) = 10;
		blocks(1,2) = number - 160;
	elseif (number >= 176) && (number < 192) 
		blocks(1,1) = 11;
		blocks(1,2) = number - 176;
	elseif (number >= 192) && (number < 208) 
		blocks(1,1) = 12;
		blocks(1,2) = number - 192;
	elseif (number >= 208) && (number < 224) 
		blocks(1,1) = 13;
		blocks(1,2) = number - 208;
	elseif (number >= 224) && (number < 240) 
		blocks(1,1) = 14;
		blocks(1,2) = number - 224;
    elseif (number >= 240)
		blocks(1,1) = 15;
		blocks(1,2) = number - 240;
    end
end