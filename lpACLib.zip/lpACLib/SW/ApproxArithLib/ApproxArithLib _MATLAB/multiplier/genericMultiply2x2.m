% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: genericMultiply2x2.m
% first  	first operand (decimal 0/1/2/3)
% second	second operand  (decimal 0/1/2/3)
% The operands can have a value between 0 and 3 (2 bit binary representation)
% multiplier 	specifies which multiplier to use
% result 		the product of the two operands
function result=genericMultiply2x2(first,second,multiplier)
    switch (multiplier) 
	case 'VER1_APPROX'
		result = first * second;
        switch(result)
		case 1
			result = 0;
		case 3
			result = 2;
        end
        
	case 'APPROX'
		result = first * second;
        if result == 9
            result = 7;
        end
        
	case 'ACCURATE_MULT'
		result = first * second;
    otherwise
        result = first * second;  
    end
end