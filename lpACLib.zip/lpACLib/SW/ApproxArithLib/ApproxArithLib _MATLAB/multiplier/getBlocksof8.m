% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getBlocksof8.m
% number a number (representable by 16 bits in binary) to be split into 2 numbers
% blocks an array of two numbers, each representable by 8 bits in binary
function blocks=getBlocksof8(number,ranges)
    elements=257;
    for i=1:1:elements-1
        if (number >= ranges(1,i)) && (number < ranges(1,i+1))
            blocks(1,1)=i-1;
            blocks(1,2)=number-ranges(1,i);
        end
    end
end