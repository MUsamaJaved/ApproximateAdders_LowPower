% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getBlocksof4WithRanges.m
% number a number (representable by 8 bits in binary) to be split into 2 numbers
% blocks an array of two numbers, each representable by 4 bits in binary
function blocks=getBlocksof4WithRanges(number,ranges)
    elements=17;
    for i=1:1:elements-1
        if (number >= ranges(1,i)) && (number < ranges(1,i+1))
            blocks(1,1)=i-1;
            blocks(1,2)=number-ranges(1,i);
        end
    end
end