% MATLAB implementation for "lpACLib" (Low Power Approximate Computing Library).
% Cpyright (C) 2016, Vanshika Baoni, Muhammad Shafique, CES, KIT
% Email: vbaoni@gmail.com, swahlah@yahoo.com

% FILE NAME: getBlocksof2.m
% number a number (representable by 4 bits in binary) to be split into 2 numbers
% blocks an array of two numbers, each representable by 2 bits in binary
function blocks=getBlocksof2(number)
    switch(number)
	case 0
		blocks(1,1) = 0; blocks(1,2) = 0;
	case 1
		blocks(1,1) = 0; blocks(1,2) = 1;
	case 2
		blocks(1,1) = 0; blocks(1,2) = 2;
	case 3
		blocks(1,1) = 0; blocks(1,2) = 3; 
	case 4
		blocks(1,1) = 1; blocks(1,2) = 0;
	case 5
		blocks(1,1) = 1; blocks(1,2) = 1;
	case 6
		blocks(1,1) = 1; blocks(1,2) = 2;
	case 7
		blocks(1,1) = 1; blocks(1,2) = 3;
	case 8
		blocks(1,1) = 2; blocks(1,2) = 0; 
	case 9
		blocks(1,1) = 2; blocks(1,2) = 1;
	case 10
		blocks(1,1) = 2; blocks(1,2) = 2;
	case 11
		blocks(1,1) = 2; blocks(1,2) = 3; 
	case 12
		blocks(1,1) = 3; blocks(1,2) = 0; 
	case 13
		blocks(1,1) = 3; blocks(1,2) = 1;
	case 14
		blocks(1,1) = 3; blocks(1,2) = 2;
	case 15
		blocks(1,1) = 3; blocks(1,2) = 3; 
    end
end