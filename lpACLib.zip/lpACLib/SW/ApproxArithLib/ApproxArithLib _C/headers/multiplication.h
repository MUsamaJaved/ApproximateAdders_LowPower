/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file multiplication.h
* @author Walaa El-Harouni
* @brief This file contains functions declaration for multiplication 
*/

#ifndef MULTIPLICATION_H_
#define MULTIPLICATION_H_

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "addition.h"

typedef enum {ACCURATE_MULT, APPROX, VER1_APPROX} Multiplier;

int* getRangesFor16x16();
int* getRangesFor8x8();

int* getBlocksof2(int number);
int* getBlocksof4(int number);
int* getBlocksof4WithRanges(int number, int* ranges);
int* getBlocksof8(int number, int* ranges);

int genericMultiply2x2(int first, int second, Multiplier multiplier);
int genericMultiply4x4(int first, int second, Multiplier multiplier[], Adder adder, int approxBits);
int genericMultiply8x8(int first, int second, Multiplier multiplier[], Adder adder, int approxBits);
long genericMultiply16x16(int first, int second, Multiplier multiplier[], Adder adder, int approxBits);

Multiplier** splitMultiplierArray(Multiplier org[], Multiplier** subArrays, int dim1, int dim2);
void freeMultiplierSubArray(Multiplier** subArrays, int dim1, int dim2);
void printMultiplierSubArray(Multiplier** subArrays, int dim1, int dim2);


#endif /* MULTIPLICATION_H_ */
