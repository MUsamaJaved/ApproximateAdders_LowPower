/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file addition.h
* @author Walaa El-Harouni
* @brief This file contains functions declaration for addition 
*/

#ifndef ADDITION_H_
#define ADDITION_H_

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef enum {C_ADD, ACCURATE_ADD, IMPACT_ZERO, IMPACT_FIRST, IMPACT_THIRD} Adder;

void initBinary(char* binary, int size);

char* decimalToBinaryUnsigned(long decimal, int size);
long binaryToDecimalUnsigned(char* binary, int size);
void testConversionsUnsigned(int size);

char* decimalToBinarySigned(long decimal, int size);
long binaryToDecimalSigned(char* binary, int size);
char* computeTwosComplement(char* binary, int size);

// Accurate version
void addOneBitAccurate(char a, char b, char cin, char* sum, char* cout);
void addMultiBitAccurate(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum);

// zero approximation versions
void addOneBitZeroApprox(char a, char b, char cin, char* sum, char* cout);
void addMultiBitZeroApprox(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum, int approxBitNum);

// first approximation versions
void addOneBitFirstApprox(char a, char b, char cin, char* sum, char* cout);
void addMultiBitFirstApprox(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum, int approxBitNum);

// third approximation versions
void addOneBitThirdApprox(char a, char b, char cin, char* sum, char* cout);
void addMultiBitThirdApprox(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum, int approxBitNum);

// generic add operation
long add (long x, long y, char cin, char* cout, Adder adder, int totalBitNum, int approxBitNum);

#endif /* ADDITION_H_ */
