/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file definitions.h
* @author Walaa El-Harouni
* @brief This file contains functions declaration for SAD 
*/

#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_

#include "addition.h"

long computeSAD(unsigned char* first, unsigned char* second, Adder adder, int opSize, int totalBits, int approxBits);
long computeSumOfSums(unsigned char* first, unsigned char* second, Adder adder, int opSize, int totalBits, int approxBits);

#endif /* DEFINITIONS_H_ */
