/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file zeroApprox.c
* @author Walaa El-Harouni
* @brief This file contains the behavioral model for 1-bit and multi-bit IM_X2 approximate
* adder
*/


#include "addition.h"

/**
 *
 * Returns the sum and a carry-out of two input bytes and a carry-in
 * by simulating the behaviour of [approximation 2] from:
 * "Low-Power Digital Signal Processing Using Approximate Adders"
 *
 * @param  a  		first operand (byte)
 * @param  b 		second operand (byte)
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 */
void addOneBitZeroApprox(char a, char b, char cin, char* sum, char* cout) {
	*cout = 0;
	*sum = 0;

	if((a == 1 && b == 1) || (cin == 1 && (a == 1 || b == 1))) {
		*cout = 1;
	}
	*sum = 1 - *cout;
}

/**
 *
 * Returns the sum and a carry-out of two input byte arrays and a carry-in
 * by simulating the behaviour of an approximate 1-bit FA @see addOneBitZeroApprox
 *
 * @param  a  		first operand (byte array)
 * @param  b 		second operand (byte array )
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 * @param  totalBitNum		the number of bits for the multi-bit adder to be simulated
 * @param  approxBitNum		the number of approx. LSBs for the multi-bit adder to be simulated
 */
void addMultiBitZeroApprox(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum, int approxBitNum) {
	int i, accurateStart;
	char* carryInternal = (char*) malloc(sizeof(char) * (totalBitNum + 1));

	accurateStart = totalBitNum - approxBitNum -1;
	carryInternal[totalBitNum] = cin;

	// add the required number of approximate LSBs using addOneBitZeroApprox
	for(i = totalBitNum - 1; i > accurateStart; i--) {
		addOneBitZeroApprox(a[i], b[i], carryInternal[i + 1], &sum[i], &carryInternal[i]);
	}
	// add the remaining bits using addOneBitAccurate
	for(i = accurateStart; i >= 0; i--) {
		addOneBitAccurate(a[i], b[i], carryInternal[i + 1], &sum[i], &carryInternal[i]);
	}
	*cout = carryInternal[0];

	free(carryInternal);
	carryInternal = NULL;
}

