/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file thirdApprox.c
* @author Walaa El-Harouni
* @brief This file contains the behavioral model for 1-bit and multi-bit IM_X5 approximate
* adder
*/

#include "addition.h"


/**
 *
 * Returns the sum and a carry-out of two input bytes and a carry-in
 * by simulating the behaviour of [approximation 3] from:
 * "IMPACT: IMPrecise adders for low-power Approximate CompuTing"
 *
 * @param  a  		first operand (byte)
 * @param  b 		second operand (byte)
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 */
void addOneBitThirdApprox(char a, char b, char cin, char* sum, char* cout) {
	*sum = b;
	*cout = a;
}

/**
 *
 * Returns the sum and a carry-out of two input byte arrays and a carry-in
 * by simulating the behaviour of an approximate 1-bit FA @see addOneBitThirdApprox
 *
 * @param  a  		first operand (byte array)
 * @param  b 		second operand (byte array )
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 * @param  totalBitNum		the number of bits for the multi-bit adder to be simulated
 * @param  approxBitNum		the number of approx. LSBs for the multi-bit adder to be simulated
 */
void addMultiBitThirdApprox(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum, int approxBitNum) {
	int i, accurateStart;
	char* carryInternal = (char*) malloc(sizeof(char) * (totalBitNum + 1));

	accurateStart = totalBitNum - approxBitNum -1;
	carryInternal[totalBitNum] = cin;

	// add the required number of approximate LSBs using addOneBitThirdApprox
	for(i = totalBitNum - 1; i > accurateStart; i--) {
		addOneBitThirdApprox(a[i], b[i], carryInternal[i + 1], &sum[i], &carryInternal[i]);
	}
	// add the remaining bits using addOneBitAccurate
	for(i = accurateStart; i >= 0; i--) {
		addOneBitAccurate(a[i], b[i], carryInternal[i + 1], &sum[i], &carryInternal[i]);
	}
	*cout = carryInternal[0];

	free(carryInternal);
	carryInternal = NULL;
}
