/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file accurate.c
* @author Walaa El-Harouni
* @brief This file contains the behavioral model for 1-bit and multi-bit accurate adder
*/

#include "addition.h"

/**
 *
 * Returns the sum and a carry-out of two input bytes and a carry-in
 * by simulating the behaviour of an accurate 1-bit FA
 *
 * @param  a  		first operand (byte)
 * @param  b 		second operand (byte)
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 */
void addOneBitAccurate(char a, char b, char cin, char* sum, char* cout) {
	char result;

	result = a + b + cin;

	// a C addition results in a sum and no carry, additional logic is needed to convert a sum
	// value into a sum and a carry-out

	if(result >= 2) { // since we are simulating a binary addition, a carry is generated if the sum is >=2
		*sum = result - 2;
		*cout = 1;
	} else {
		*sum = result;
		*cout = 0;
	}
}


/**
 *
 * Returns the sum and a carry-out of two input byte arrays and a carry-in
 * by simulating the behaviour of an accurate multi-bit FA
 *
 * @param  a  		first operand (byte array)
 * @param  b 		second operand (byte array )
 * @param  cin 		carry-in (byte)
 * @param  sum 		pointer to the location to store the resulting sum
 * @param  cout		pointer to the location to store the resulting cout
 * @param  totalBitNum		the number of bits for the multi-bit adder to be simulated
 */

void addMultiBitAccurate(char* a, char* b, char cin, char* sum, char* cout, int totalBitNum) {
	int i;
	char* carryInternal = (char*)malloc(sizeof(char) * (totalBitNum + 1));

	// index 0 is the MSB
	carryInternal[totalBitNum] = cin;
	for(i = totalBitNum - 1; i >= 0; i--) {
		addOneBitAccurate(a[i], b[i], carryInternal[i + 1], &sum[i], &carryInternal[i]);
	}
	*cout = carryInternal[0];

	free(carryInternal);
	carryInternal = NULL;
}
