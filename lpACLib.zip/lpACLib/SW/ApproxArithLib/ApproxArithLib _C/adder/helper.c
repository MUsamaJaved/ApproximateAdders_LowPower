/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file helper.c
* @author Walaa El-Harouni
* @brief This file contains some helper functions
*/

#include "addition.h"

/**
 *
 * initializes a given binary array to zeros
 *
 * @param  a  		binary array to initialize
 * @param  size 	the size of the array
 */
void initBinary(char* binary, int size) {
	int i;

	for(i = 0; i < size; i++) {
		binary[i] = 0;
	}
}


/**
 *
 * converts a decimal number to binary (unsigned)
 *
 * @param  decimal	the decimal number to be converted
 * @param  size 	the required size of the resulting binary array
 * @return binary	a binary array
 * starting point: http://www.programiz.com/c-programming/examples/binary-decimal-convert
 */
char* decimalToBinaryUnsigned(long decimal, int size) {
	int rem;
    int index = size - 1;
    char* binary = (char*) malloc(sizeof(char) * size);
    initBinary(binary, size);

    while (decimal != 0)
    {
        rem = decimal % 2;
        decimal /= 2;
        binary[index] = rem;
        index--;
    }
    return binary;
}

/**
 *
 * converts a binary array to a decimal number (Unsigned)
 *
 * @param  size 	the size of the binary array
 * @param binary	the binary array to be converted
 * @return  decimal	the resulting decimal number
 */
long binaryToDecimalUnsigned(char* binary, int size) {
    long i, decimal = 0;
    long lastIndex = size - 1;

    for(i = 0; i < size; i++) {
    	decimal += binary[i] * pow (2, lastIndex - i);
    }
    return decimal;
}


/**
 *
 * converts a decimal number to binary (signed)
 *
 * @param  decimal	the decimal number to be converted
 * @param  size 	the required size of the resulting binary array
 * @return binary	a binary array
 */
char* decimalToBinarySigned(long decimal, int size) {
	long magnitude;
	char* toComplement = NULL;
	char* binary = NULL;

	if(decimal >= 0) {
		return decimalToBinaryUnsigned(decimal, size);
	}

	magnitude = decimal * (-1);
	toComplement = decimalToBinaryUnsigned(magnitude, size);
	binary = computeTwosComplement(toComplement, size);

	free(toComplement);
	return(binary);
}

/**
 *
 * converts a binary array to a decimal number (signed)
 *
 * @param  size 	the size of the binary array
 * @param binary	the binary array to be converted
 * @return  decimal	the resulting decimal number
 */
long binaryToDecimalSigned(char* binary, int size) {
	long decimal = 0;
	int i;
	char cout;
	char* inverted = (char*) malloc(size * sizeof(char));
	char* one = (char*) malloc(size * sizeof(char));
	char* result = (char*) malloc(size * sizeof(char));

	if(binary[0] == 0) {
		return binaryToDecimalUnsigned(binary, size);
	}

	initBinary(one, size);
	one[size - 1] = 1;

	//inverting bits
	for (i = 0; i < size; i++) {
		inverted[i] = 1 - binary[i];
	}

	// add 1
	addMultiBitAccurate(inverted, one, 0, result, &cout, size);
	decimal = binaryToDecimalUnsigned(result, size);

	free(inverted);
	free(one);
	free(result);
	return decimal * (-1);
}

/**
 *
 * converts a binary array to a decimal number (signed)
 *
 * @param  size 	the size of the binary array
 * @param binary	the binary array to be converted
 * @return twosComplement	the two's complement representation of the given binary number
 */
char* computeTwosComplement(char* binary, int size) {
	int i;
	char cout;
    char* inverted = (char*)malloc(size * sizeof(char));
    char* twosComplement = (char*)malloc(size * sizeof(char));
    char* one = (char*)malloc(size * sizeof(char));

    initBinary(one, size);
    one[size - 1] = 1;

    //inverting bits
    for(i = 0; i < size; i++) {
    	inverted[i] = 1 - binary[i];
    }

    // add 1
   addMultiBitAccurate(inverted, one, 0, twosComplement, &cout, size);

   	free(inverted);
    free(one);
    return twosComplement;
}

/**
 *
 * A testing function to check that the conversion functions are working properly
 *
 * @param  size 	the size of the binary array
 */

void testConversionsUnsigned(int size) {
	char* binary = (char*)malloc(size * sizeof(char));
	long decimal, i, j;

	for(i = 0; i < size*size; i++) {
		printf("%ld \t", i);

		initBinary(binary, size);
		for(j = 0; j < size; j++) {
			printf("%c", binary[j]);
		}
		putchar('\t');


		binary = decimalToBinaryUnsigned(i, size);
		for(j = 0; j < size; j++) {
			printf("%c", binary[j]);
		}
		putchar('\t');

		decimal = binaryToDecimalUnsigned(binary, size);
		printf("%ld \n",decimal);
	}
}
