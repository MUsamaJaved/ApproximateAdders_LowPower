/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file genericAdder.c
* @author Walaa El-Harouni
* @brief This file contains the behavioral model for a generic adder supporting:
* the accurate adder and the three approximate versions
*/


#include "addition.h"


/**
 *
 * A generic adder that can simulate the adder behaviours in @see Adder
 * Returns the sum and a carry-out of two input numbers and a carry-in
 *
 * @param  x  		first operand
 * @param  y 		second operand
 * @param  cin 		carry-in (byte)
 * @param  cout		pointer to the location to store the resulting cout
 * @param  adder 	adder-type
 * @param  totalBitNum		the number of bits for the multi-bit adder to be simulated
 * @param  approxBitNum		the number of approx. LSBs for the multi-bit adder to be simulated
 *
 * totalBitNum should include an additional two bits; one for the carry and the other for the sign
 * cout can be safely removed
 *
 * @return decimalSum
 */
long add (long x, long y, char cin, char* cout, Adder adder, int totalBitNum, int approxBitNum) {
	char* binaryX = NULL;
	char* binaryY = NULL;
	char* sum = NULL;
	long decimalSum;

	// C addition
	if(adder == C_ADD) {
		decimalSum = x + y;
		cout = 0;
		return decimalSum;
	}

	// convert the two decimal operands to binary
	sum = (char*) malloc(sizeof(char) * totalBitNum);
	binaryX = decimalToBinarySigned(x, totalBitNum);
	binaryY = decimalToBinarySigned(y, totalBitNum);

	//apply addition according to the given settings
	switch (adder) {
		case IMPACT_ZERO:
			addMultiBitZeroApprox(binaryX, binaryY, cin, sum, cout, totalBitNum, approxBitNum);
			break;
		case IMPACT_FIRST:
			addMultiBitFirstApprox(binaryX, binaryY, cin, sum, cout, totalBitNum, approxBitNum);
			break;
		case IMPACT_THIRD:
			addMultiBitThirdApprox(binaryX, binaryY, cin, sum, cout, totalBitNum, approxBitNum);
			break;
		case ACCURATE_ADD:
		default:
			addMultiBitAccurate(binaryX, binaryY, cin, sum, cout, totalBitNum);
			break;
	}
	// convert binary back to decimal
	decimalSum = binaryToDecimalSigned(sum, totalBitNum);

	//clean-up
	free(binaryX);
	free(binaryY);
	free(sum);

	return decimalSum;
}
