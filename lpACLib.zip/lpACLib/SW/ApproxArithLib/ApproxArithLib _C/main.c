/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/


/**
* @file main.c
* @author Walaa El-Harouni
* @brief This file contains functions which were used for testing the source code
*/

#include "multiplication.h"
#include "statistics.h"
#include "definitions.h"

/**
 * Tests two's complement by converting a decimal number to binary and back
 */
void testTwosComplement() {
	int i;
    int bits = 6;
    int decimal = -20;
    long returnedDecimal;

    char* twosCompl = NULL;
    char* binary = (char*)malloc(bits * sizeof(char));

    initBinary(binary, bits);
    twosCompl = decimalToBinarySigned(decimal, bits);

    for(i = 0; i < bits; i++) {
    	printf("%d", twosCompl[i]);
    }
    printf("\n");

    returnedDecimal = binaryToDecimalSigned(twosCompl, bits);
    printf("%ld", returnedDecimal);
}

/** 
*
* Runs tests for 4x4 generic multiplication
* Adder, approxBits, and multiplier for each 2x2 block can be set
* includes reporting to file (if needed)
*/
void test4x4Generic() {
    int bits = 4;
    int size = pow(2, bits);

    int  i, j;
    int correct, error, result;
    int blocksNum = 4;
    Adder adder = IMPACT_ZERO;
    int approxBits = 0;

    Multiplier* multiplier = (Multiplier*)malloc(blocksNum * sizeof(Multiplier));

//    FILE *fp = NULL;
//	fp = fopen("4x4_Adder0_ab8_ErrorCases.txt", "w");
//	if (fp == NULL)
//	{
//		printf("Error opening file!\n");
//		exit(1);
//	}

    for(i = 0; i < blocksNum; i++) {
    	multiplier[i] = ACCURATE_MULT;
    }

    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++) {
            result = genericMultiply4x4(i, j, multiplier, adder, approxBits);
            correct = i * j;
            error = abs(correct - result);
//            if(error != 0) {
//               fprintf(fp, "%d * %d = %d , correct = %d, error = %d \n", i, j, result, correct, error);
//            }
        }
    }

    //fclose(fp);
    free(multiplier);
}

/** 
*
* Runs tests for 8x8 generic multiplication
* Adder, approxBits, and multiplier for each 2x2 block can be set
* includes reporting to file (if needed)
*/
void test8x8Generic() {
    int bits = 8;
    int size = pow(2, bits);
    long statisticsSize = (size * size);

    int  i, j;
    long correct, error, result;
    int blocksNum = 16;
    Adder adder = IMPACT_THIRD;
    int approxBits = 8;

    int statsFilenameLimit = 30;
    char* statsFilename = (char*)malloc(statsFilenameLimit * sizeof(char));
    statsFilename = "ApproxOwn_Adder3_8LSB.csv";

    Multiplier* multiplier = (Multiplier*)malloc(blocksNum * sizeof(Multiplier));

	struct errorEntry* statisctics = (struct errorEntry*)malloc(sizeof(struct errorEntry) * statisticsSize);
	if (statisctics == NULL) {
	    printf("Error allocating statistics!\n");
	    exit(1);
	}

	statisctics = initStatistics(statisctics, statisticsSize);
	printf("finished statistics initialization \n");

    FILE *fp = NULL;
	fp = fopen("ApproxOwn_Adder3_8LSB.txt", "w");
	if (fp == NULL)
	{
		printf("Error opening file!\n");
		exit(1);
	}

    for(i = 0; i < blocksNum; i++) {
    	multiplier[i] = VER1_APPROX;
    }

    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++) {
            result = genericMultiply8x8(i, j, multiplier, adder, approxBits);
            correct = i * j;
            error = labs(correct - result);
            if(error != 0) {
            	statisctics = updateStatistics(statisctics, error, statisticsSize);
                fprintf(fp, "%d * %d = %ld , correct = %ld, error = %ld \n", i, j, result, correct, error);
            }
        }
    }

    	fclose(fp);
    free(multiplier);
    printStatistics(statisctics, statisticsSize, statsFilename);
}

/** 
*
* Runs tests for 16x16 generic multiplication
* Adder, approxBits, and multiplier for each 2x2 block can be set
* includes reporting to file (if needed)
*/
void test16x16Generic() {
    int bits = 16;
    int size = pow(2, bits);
    int start;

    long  i, j;
    long correct, error, result;
    int blocksNum = 64;
    Adder adder = C_ADD;
    int approxBits = 0;

    Multiplier* multiplier = (Multiplier*)malloc(blocksNum * sizeof(Multiplier));

    for(i = 0; i < blocksNum; i++) {
        multiplier[i] = ACCURATE_MULT;
    }

    FILE *fp = NULL;
	fp = fopen("Generic16x16ErrorCases.txt", "w");
	if (fp == NULL)
	{
		printf("Error opening file!\n");
		exit(1);
	}

    start = -300;
    size = 300;
    for(i = start; i < size; i++) {
        for(j = start; j < size; j++) {
            result = genericMultiply16x16(i, j, multiplier, adder, approxBits);
            correct = i * j;
            error = labs(correct - result);
            if(error != 0) {
                fprintf(fp, "%ld * %ld = %ld , correct = %ld, error = %ld \n", i, j, result, correct, error);
            }
        }
    }
    fclose(fp);
    free(multiplier);
}


/**
*
* Runs tests for computeSAD
* Adder, totalBits, and approxBits can be set
* includes several test-cases, comment and uncomment as needed
*/
void testSAD() {
	long sad;
	Adder adder = IMPACT_ZERO;
	int opSize = 9;
	int totalBits = 10;
	int approxBits = 0;

//	unsigned char first[6] =  { 0, 42, 6, 0, 58, 14 };
//	unsigned char second[6] = { 0, 0, 16, 0, 96, 16 }; // should be 92
//	unsigned char first[9] =  { 255, 5, 5, 4, 0, 7, 7, 5, 109 };
//	unsigned char second[9] = { 255, 7, 5, 1, 7, 4, 8, 4, 106 };// should be 20
//	unsigned char first[9] =  { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
//	unsigned char second[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };// should be 0
//	unsigned char first[9] =  { 255, 5, 5, 0, 0, 7, 0, 5, 109 };
//	unsigned char second[9] = { 255, 7, 5, 0, 7, 4, 0, 4, 106 };// should be 16
	unsigned char first[9] =  { 255, 255, 255, 255, 0, 0, 0, 0, 0 };
	unsigned char second[9] = { 0	, 0	, 0	 , 0  , 0, 0, 255, 255, 255 };// should be 1785
	sad = computeSAD(first, second, adder, opSize, totalBits, approxBits);
	printf("SAD = %ld", sad);
}

/** 
*
* Runs tests for computeSumOfSums
* Adder, totalBits, and approxBits can be set
* includes several test-cases, comment and uncomment as needed
*/
void testSumOfSums() {
	long sad;
	Adder adder = IMPACT_THIRD;
	int opSize = 9;
	int totalBits = 10;
	int approxBits = 0;

//	unsigned char first[6] =  { 0, 42, 6, 0, 58, 14 };
//	unsigned char second[6] = { 0, 0, 16, 0, 96, 16 }; // should be 248
	unsigned char first[9] =  { 255, 5, 5, 4, 0, 7, 7, 5, 109 };
	unsigned char second[9] = { 255, 7, 5, 1, 7, 4, 8, 4, 106 };// should be 794 => wrong for 9 bits
//	unsigned char first[10] =  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
//	unsigned char second[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};// should be 0

	sad = computeSumOfSums(first, second, adder, opSize, totalBits, approxBits);
	printf("SAD = %ld", sad);
}

/**
*
* Runs tests for the generic addition function for two 8-bit numbers
* Adder, totalBits, and approxBits can be set
* includes several test-cases, comment and uncomment as needed
*/
void test8x8Adder() {
    int bits = 8;
    int size = pow(2, bits);

    int  i, j;
    char cin = 0;
    char cout;
    long posError = 0;
    long negError = 0;

    long correct, error, result;
    Adder adder = IMPACT_ZERO;
    int totalBitNum = 10;
    int approxBits = 4;

    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++) {
        	result = add (i, j, cin,  &cout, adder, totalBitNum, approxBits);
            correct = i + j;
            error = correct - result;
            if(error < 0) {
            	negError++;
               // printf( "%d * %d = %ld , correct = %ld, error = %ld \n", i, j, result, correct, error);
            } else if (error > 0) {
            	posError++;
            }
        }
    }

    printf("posError = %ld \n", posError);
    printf("negError = %ld \n", negError);

}

/** 
*
* main function calls any of the above testing functions.
*/
int main(int argc, char *argv[]) {
	//int bits = 4;
	//testConversionsUnsigned(bits);

	//test8x8Adder();
	//testSAD();
	//testSumOfSums();

	//testTwosComplement();

	//test4x4Generic();
    test8x8Generic();
//    test16x16Generic();

/*
    int  i, j;
    int correct, error, result;
    int blocksNum = 64;
    int adder = IMPACT_THIRD;
    int approxBits = 0;

    Multiplier* multiplier = (Multiplier*)malloc(blocksNum * sizeof(Multiplier));

    for(i = 0; i < blocksNum; i++) {
    	  multiplier[i] = ACCURATE_MULT;
    }

    i = -226;
    j = 104;
	result = genericMultiply16x16(i, j, multiplier, adder, approxBits);
	correct = i * j;
	error = abs(correct - result);
	printf("%d * %d = %d , correct = %d, error = %d \n", i, j, result, correct, error);

    free(multiplier);
    */

}
