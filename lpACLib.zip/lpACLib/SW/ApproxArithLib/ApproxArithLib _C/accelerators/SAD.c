/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/


/*
 * @file SAD.c
 * @author Walaa El-Harouni
 *
 */

#include "definitions.h"


/**
 * Returns the Sum-of-Absolute-Differences (SAD) value given two byte arrays
 * and adder configuration settings.
 * The values at corresponding locations in the two input arrays are subtracted,
 * magnitude of the results are then summed.
 *
 * @param  first  		an array of bytes as the first operand
 * @param  second 		an array of bytes as the second operand
 * @param  adder 		the type of adder to use, the accurate or one of the available approximations @see Adder
 * @param  opSize 		the size of the arrays
 * @param  totalBits	the total number of bits to set when adding
 * @param  approxBits	the number of approximate LSBs to set when adding
 * @return      SAD
 */
long computeSAD(unsigned char* first, unsigned char* second, Adder adder, int opSize, int totalBits, int approxBits) {
	static int cin = 0;
	char cout;
	long diff;
	long sad = 0;
	int i;

	for(i = 0; i < opSize; i++) {
//		printf("x = %ld \t", (long)first[i]);
//		printf("y = %ld \n", -1*((long)second[i]));

		//call the generic add function, and send the adder-type, number of bits and approx LSBs
		diff = add ((long)first[i], -1*((long)second[i]), cin, &cout, adder, totalBits, approxBits);
		sad += labs(diff);

//		printf("diff = %ld \t", diff);
//		printf("sad = %ld \n", sad);
//		printf("=============\n");
	}

	return sad;
}

/**
 * ONLY FOR TESTING
 *
 * Exactly like SAD but using addition instead of subtractions.
 * The values at corresponding locations in the two input arrays are added,
 * magnitude of the results are then summed.
 *
 * @param  first  		an array of bytes as the first operand
 * @param  second 		an array of bytes as the second operand
 * @param  adder 		the type of adder to use, the accurate or one of the available approximations @see Adder
 * @param  opSize 		the size of the arrays
 * @param  totalBits	the total number of bits to set when adding
 * @param  approxBits	the number of approximate LSBs to set when adding
 * @return      SAD
 */

long computeSumOfSums(unsigned char* first, unsigned char* second, Adder adder, int opSize, int totalBits, int approxBits) {
	static int cin = 0;
	char cout;
	long diff;
	long sum = 0;
	int i;

	for(i = 0; i < opSize; i++) {
		diff = add ((long)first[i], (long)second[i], cin, &cout, adder, totalBits, approxBits);
		sum += labs(diff);
	}

	return sum;
}
