/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file genericMult.c
* @author Walaa El-Harouni
* @brief This file contains generic multiplication functions supporting:
* accurate and both approximate versions.
*/

#include "multiplication.h"

/**
 *
 * Returns the product of two input numbers using a specified multiplier
 * Both operands can have a value between 0 and 3 (2-bit binary representation)
 *
 * In case of APPROX: multiplication is carried out by simulating the behaviour
 * from: "Trading Accuracy for Power with an Under-designed Multiplier Architecture"
 *
 * In case of VER1_APPROX: multiplication is carried out by simulating the behaviour
 * of V1 approximate multiplier developed by Walaa El-Harouni
 *
 * @param  first  	first operand
 * @param  second	second operand
 * @param  multiplier 	specifies which multiplier o use
 * @return result 		the product of the two operands
 */
int genericMultiply2x2(int first, int second, Multiplier multiplier) {
	int result;

	switch (multiplier) {
	case VER1_APPROX:
		result = first * second;
		switch(result) {
		case 1:
			result = 0; break;
		case 3:
			result = 2; break;
		}
		break;
	case APPROX:
		result = first * second;
		if(result == 9) {
			result = 7;
		}
		break;
	case ACCURATE_MULT:
	default:
		result = first * second;
	}
	return result;
}

/**
 *
 * Returns the product of two input numbers using a specified multiplier
 * Both operands must have a binary representation of no wider than 4-bits
 *
 *
 * @param  first  	first operand
 * @param  second	second operand
 * @param  multiplier 	an array of 4 multipliers specifying the multiplier for each of the 2x2 multipliers needed
 * @param  adder		the adder-type to use when summing the partial products
 * @param  approxBits  the number of approx. LSBs to apply when adding (maximum is 8)
 * @return result 		the product of the two operands
 */
int genericMultiply4x4(int first, int second, Multiplier multiplier[], Adder adder, int approxBits) {
	int aH, aL, xH, xL;
	int row1, row2, row3, row4;
	int* temp = NULL;
	int product = 0;
	int totalBitNum = 8 + 2;
//	int totalBitNum = 8;
//	int size = pow(2, totalBitNum);
	char carry = 0;

	// split the first operand into two 2-bit numbers
	temp = getBlocksof2(first);
	aH = temp[0];
	aL = temp[1];
	free(temp);

	// split the second operand into two 2-bit numbers
	temp = getBlocksof2(second);
	xH = temp[0];
	xL = temp[1];
	free(temp);

	// 4 calls to the generic 2x2 multiplication function using the specified multiplier
	row1 = genericMultiply2x2(aL, xL, multiplier[0]);
	row2 = genericMultiply2x2(aH, xL, multiplier[1]);
	row3 = genericMultiply2x2(aL, xH, multiplier[2]);
	row4 = genericMultiply2x2(aH, xH, multiplier[3]);

	// 3 calls to the generic add function using the specified addition settings
	product = add (row1   , row2 * 4  , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 4  , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 16 , carry,  &carry, adder, totalBitNum, approxBits);

	//return product + (carry * size);
	return product;
}



/**
 *
 * Returns the product of two input numbers using a specified multiplier
 * Both operands must have a binary representation of no wider than 8-bits
 *
 *
 * @param  first  	first operand
 * @param  second	second operand
 * @param  multiplier 	an array of 16 multipliers specifying the multiplier for each of the 2x2 multipliers needed
 * @param  adder		the adder-type to use when summing the partial products
 * @param  approxBits  the number of approx. LSBs to apply when adding (maximum is 16)
 * @return result 		the product of the two operands
 */
int genericMultiply8x8(int first, int second, Multiplier multiplier[], Adder adder, int approxBits) {
	int aH, aL, xH, xL;
	int row1, row2, row3, row4;
    
	int product = 0;
	int elements = 16;
	int dim2 = 4;
    int dim1 = elements/dim2;
    int totalBitNum = 16 + 2;
//    int size = pow(2, totalBitNum);
    char carry = 0;

    // allow for signed multiplication
	int firstSign = 1;
	int secondSign = 1;
	if(first < 0) {
		first = first * -1;
		firstSign = -1;
	}
	if(second < 0) {
		second = second * -1;
		secondSign = -1;
	}

	int* temp = NULL;
	int* ranges8x8 = NULL;

	Multiplier** multiplierSub = NULL;

	// split the first operand into two 4-bit numbers
	ranges8x8 = getRangesFor8x8();
	temp = getBlocksof4WithRanges(first, ranges8x8);
	aH = temp[0];
	aL = temp[1];
	free(temp);

	// split the second operand into two 4-bit numbers
	temp = getBlocksof4WithRanges(second, ranges8x8);
	xH = temp[0];
	xL = temp[1];
	free(temp);

	//split the multiplier array into 4 sub-arrays, each of size 4
	multiplierSub = splitMultiplierArray(multiplier, multiplierSub, dim1, dim2);
    
	// 4 calls to the generic 4x4 multiplication function using the specified multiplier and adder settings
	row1 = genericMultiply4x4(aL, xL, multiplierSub[0], adder, approxBits); // 0 ->3
	row2 = genericMultiply4x4(aH, xL, multiplierSub[1], adder, approxBits); // 4 -> 7
	row3 = genericMultiply4x4(aL, xH, multiplierSub[2], adder, approxBits); // 8 -> 11
	row4 = genericMultiply4x4(aH, xH, multiplierSub[3], adder, approxBits); // 12 -> 15

	// 3 calls to the generic add function using the specified addition settings
	product = add (row1   , row2 * 16 , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 16 , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 256, carry,  &carry, adder, totalBitNum, approxBits);

	free(ranges8x8);
    freeMultiplierSubArray(multiplierSub, dim1, dim2);

    //return product + (carry * size);
    return product * firstSign * secondSign;
}


/**
 *
 * Returns the product of two input numbers using a specified multiplier
 * Both operands must have a binary representation of no wider than 8-bits
 *
 *
 * @param  first  	first operand
 * @param  second	second operand
 * @param  multiplier 	an array of 64 multipliers specifying the multiplier for each of the 2x2 multipliers needed
 * @param  adder		the adder-type to use when summing the partial products
 * @param  approxBits  the number of approx. LSBs to apply when adding (maximum is 32)
 * @return result 		the product of the two operands
 */
long genericMultiply16x16(int first, int second, Multiplier multiplier[], Adder adder, int approxBits) {
	int aH, aL, xH, xL;
	long row1, row2, row3, row4;
	long product = 0;
	int elements = 64;
	int dim2 = 16;
    int dim1 = elements/dim2;
    int totalBitNum = 32 + 2;
    char carry = 0;
    int maxNum = pow(2, 16);

	int* temp = NULL;
	int* ranges8x8 = NULL;
	int* ranges16x16 = NULL;

	Multiplier** multiplierSub = NULL;

	int firstSign = 1;
	int secondSign = 1;
	if(first < 0) {
		firstSign = -1;
		first = first + maxNum;
	}
	if(second < 0) {
		secondSign = -1;
		second = second + maxNum;
	}

	// split the first operand into two 8-bit numbers
	ranges8x8 = getRangesFor8x8();
	ranges16x16 = getRangesFor16x16();

	temp = getBlocksof8(first, ranges16x16);
	aH = temp[0];
	aL = temp[1];
	free(temp);

	// split the second operand into two 8-bit numbers
	temp = getBlocksof8(second, ranges16x16);
	xH = temp[0];
	xL = temp[1];
	free(temp);

	//split the multiplier array into 4 sub-arrays, each of size 16
	multiplierSub = splitMultiplierArray(multiplier, multiplierSub, dim1, dim2);

	// 4 calls to the generic 8x8 multiplication function using the specified multiplier and adder settings
	row1 = genericMultiply8x8(aL, xL, multiplierSub[0], adder, approxBits); // 0 ->15
	row2 = genericMultiply8x8(aH, xL, multiplierSub[1], adder, approxBits); // 16 -> 31
	row3 = genericMultiply8x8(aL, xH, multiplierSub[2], adder, approxBits); // 32 -> 47
	row4 = genericMultiply8x8(aH, xH, multiplierSub[3], adder, approxBits); // 48 -> 63

	// 3 calls to the generic add function using the specified addition settings
	product = add (row1   , row2 * 256  , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row3 * 256  , carry,  &carry, adder, totalBitNum, approxBits);
	product = add (product, row4 * 65536, carry,  &carry, adder, totalBitNum, approxBits);

	free(ranges8x8);
	free(ranges16x16);
    freeMultiplierSubArray(multiplierSub, dim1, dim2);


    char* binSigned = decimalToBinarySigned(product, totalBitNum);
//    int i;
//    for (i = 0; i < totalBitNum; i++) {
//    	printf("%d",binSigned[i]);
//    }
//    printf("\n");
    char* binProduct = binSigned + 18;
    product =  binaryToDecimalUnsigned(binProduct, 16);

    if (firstSign != secondSign) {
    	product = product - pow(2, 16) ;
    }

    return product;
}
