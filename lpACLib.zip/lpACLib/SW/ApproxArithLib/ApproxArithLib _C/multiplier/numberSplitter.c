/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file numberSplitter.c
* @author Walaa El-Harouni
* @brief this file contains number splitting functionality needed for recursive multiplication
*/

#include "multiplication.h"


/**
 *
 * Splits an integer (representable by maximum 4-bits in binary), into two integers (each representable by 2-bits in binary)
 * Required for 4x4 multiplication.
 *
 * @param  number  	a number (representable by 4-bits in binary) to split into 2 numbers
 * @return blocks 	an array of two numbers, each representable by 2-bits in binary
 */
int* getBlocksof2(int number) {
	int* blocks = (int*)malloc(2 * sizeof(int));

	switch(number){
	case 0:
		blocks[0] = 0; blocks[1] = 0; break;
	case 1:
		blocks[0] = 0; blocks[1] = 1; break;
	case 2:
		blocks[0] = 0; blocks[1] = 2; break;
	case 3:
		blocks[0] = 0; blocks[1] = 3; break;
	case 4:
		blocks[0] = 1; blocks[1] = 0; break;
	case 5:
		blocks[0] = 1; blocks[1] = 1; break;
	case 6:
		blocks[0] = 1; blocks[1] = 2; break;
	case 7:
		blocks[0] = 1; blocks[1] = 3; break;
	case 8:
		blocks[0] = 2; blocks[1] = 0; break;
	case 9:
		blocks[0] = 2; blocks[1] = 1; break;
	case 10:
		blocks[0] = 2; blocks[1] = 2; break;
	case 11:
		blocks[0] = 2; blocks[1] = 3; break;
	case 12:
		blocks[0] = 3; blocks[1] = 0; break;
	case 13:
		blocks[0] = 3; blocks[1] = 1; break;
	case 14:
		blocks[0] = 3; blocks[1] = 2; break;
	case 15:
		blocks[0] = 3; blocks[1] = 3; break;
	}
	return blocks;
}
// ================== 4x4 end ========================

// ================== 8x8 start ========================
/**
 *
 * @deprecated use {@link #getRangesFor8x8()} and {@link #getBlocksof4WithRanges()} instead.
 * Splits an integer (representable by maximum 8-bits in binary), into two integers (each representable by 4-bits in binary)
 * Required for 8x8 multiplication.
 *
 * @param  number  	a number (representable by 8-bits in binary) to split into 2 numbers
 * @return blocks 	an array of two numbers, each representable by 4-bits in binary
 */
int* getBlocksof4(int number) {
	int* blocks = (int*)malloc(2 * sizeof(int));

	if(number < 16) {
		blocks[0] = 0;
		blocks[1] = number;
	} else if(number >= 16 && number < 32) {
		blocks[0] = 1;
		blocks[1] = number - 16;
	} else if(number >= 32 && number < 48) {
		blocks[0] = 2;
		blocks[1] = number - 32;
	} else if (number >= 48 && number < 64) {
		blocks[0] = 3;
		blocks[1] = number - 48;
	} else if (number >= 64 && number < 80) {
		blocks[0] = 4;
		blocks[1] = number - 64;
	} else if (number >= 80 && number < 96) {
		blocks[0] = 5;
		blocks[1] = number - 80;
	} else if (number >= 96 && number < 112) {
		blocks[0] = 6;
		blocks[1] = number - 96;
	} else if (number >= 112 && number < 128) {
		blocks[0] = 7;
		blocks[1] = number - 112;
	} else if (number >= 128 && number < 144) {
		blocks[0] = 8;
		blocks[1] = number - 128;
	} else if (number >= 144 && number < 160) {
		blocks[0] = 9;
		blocks[1] = number - 144;
	} else if (number >= 160 && number < 176) {
		blocks[0] = 10;
		blocks[1] = number - 160;
	} else if (number >= 176 && number < 192) {
		blocks[0] = 11;
		blocks[1] = number - 176;
	} else if (number >= 192 && number < 208) {
		blocks[0] = 12;
		blocks[1] = number - 192;
	} else if (number >= 208 && number < 224) {
		blocks[0] = 13;
		blocks[1] = number - 208;
	}  else if (number >= 224 && number < 240) {
		blocks[0] = 14;
		blocks[1] = number - 224;
	} else if (number >= 240){
		blocks[0] = 15;
		blocks[1] = number - 240;
	}

	return blocks;
}

/**
 *
 * Gets the ranges needed for splitting an integer (representable by maximum 8-bits in binary), into two integers (each representable by 4-bits in binary)
 * Required for 8x8 multiplication.
 *
 * @param  number  	a number (representable by 8-bits in binary) to split into 2 numbers
 * @return ranges 	an array values representing the block ranges
 */
int* getRangesFor8x8() {
	int elements = 17;
	int* ranges = (int*)malloc(elements * sizeof(int));
	int value = 0;
	int i;

	for(i = 0; i < elements; i++) {
		ranges[i] = value;
		value += 16;
	}
	return ranges;
}

/**
 *
 * Splits an integer (representable by maximum 8-bits in binary), into two integers (each representable by 4-bits in binary)
 * Required for 8x8 multiplication.
 *
 * This is a cleaner way than using long if-else statements as in getBlocksof4().
 *
 * @param  number  	a number (representable by 8-bits in binary) to split into 2 numbers
 * @return blocks 	an array of two numbers, each representable by 4-bits in binary
 */
int* getBlocksof4WithRanges(int number, int* ranges) {
	int* blocks = (int*)malloc(2 * sizeof(int));
	int elements = 17;
	int i = 0;

	// look for correct range for the number
	for(i = 0; i < elements - 1; i++) {
		if(number >= ranges[i] && number < ranges[i+1]) {
			blocks[0] = i;
			blocks[1] = number - ranges[i];
			break;
		}
	}
	return blocks;
}
// ================== 8x8 end ========================

// ================== 16x16 start ========================
/**
 *
 * Gets the ranges needed for splitting an integer (representable by maximum 16-bits in binary), into two integers (each representable by 8-bits in binary)
 * Required for 16x16 multiplication.
 *
 * @param  number  	a number (representable by 16-bits in binary) to split into 2 numbers
 * @return ranges 	an array values representing the block ranges
 */
int* getRangesFor16x16() {
	int elements = 257;
	int* ranges = (int*)malloc(elements * sizeof(int));
	int i;
	int value = 0;

	for(i = 0; i < elements; i++) {
		ranges[i] = value;
		value += 256;
	}

	return ranges;
}

/**
 *
 * Splits an integer (representable by maximum 16-bits in binary), into two integers (each representable by 8-bits in binary)
 * Required for 8x8 multiplication.
 *
 * This is a cleaner way than using long if-else statements as in getBlocksof4().
 *
 * @param  number  	a number (representable by 16-bits in binary) to split into 2 numbers
 * @return blocks 	an array of two numbers, each representable by 8-bits in binary
 */
int* getBlocksof8(int number, int* ranges) {
	int* blocks = (int*)malloc(2 * sizeof(int));
	int elements = 257;
	int i = 0;

	// look for correct range for the number
	for(i = 0; i < elements - 1; i++) {
		if(number >= ranges[i] && number < ranges[i+1]) {
			blocks[0] = i;
			blocks[1] = number - ranges[i];
			break;
		}
	}
	return blocks;
}
// ================== 16x16 end ========================
