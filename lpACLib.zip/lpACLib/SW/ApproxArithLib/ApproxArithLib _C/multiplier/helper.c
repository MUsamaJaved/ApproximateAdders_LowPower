/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file helper.c
* @author Walaa El-Harouni
*/

#include "multiplication.h"


/**
 *
 * Splits an array of Multiplier into "dim1" sub-arrays each of size "dim2"
 * needed for recursive multiplication calls
 *
 * @param  org  	the original array of multipliers
 * @param subArrays the unallocated, uninitialized 2D-array to be returned after processing
 * @param dim1
 * @param dim2
 * @return subArrays the filled 2D-array
 */
Multiplier** splitMultiplierArray(Multiplier org[], Multiplier** subArrays, int dim1, int dim2) {
	int i, j;

	//allocating the subArrays
	subArrays = (Multiplier**)malloc(dim1 * sizeof(Multiplier*));
	for(i = 0; i < dim1; i++) {
		subArrays[i] = (Multiplier*)malloc(dim2 * sizeof(Multiplier));
	}

	//splitting
	for(i = 0; i < dim1; i++) {
		for(j = 0; j < dim2; j++) {
			subArrays[i][j] = org[i*dim2 + j];
		}
	}

	return subArrays;
}


/**
 *
 * Deallocated a previously created multiplier sub-arrays.
 *
 * @param subArrays 2D-array to be deallocated
 * @param elementsNum
 * @param dim2
 */
void freeMultiplierSubArray(Multiplier** subArrays, int elementsNum, int dim2) {
	int i;
	int dim1 = elementsNum / dim2;
    
	for(i = 0; i < dim1; i++) {
		free(subArrays[i]);
	}
	free(subArrays);
}

/**
 *
 * For testing purposes ONLY
 *
 * @param subArrays 2D-array to be deallocated
 * @param dim1
 * @param dim2
 */
void printBooleanSubArray(Multiplier** subArrays, int dim1, int dim2) {
    int i, j;
    
    for(i = 0; i < dim1; i++) {
        for(j = 0; j < dim2; j++) {
            printf("i = %d, j = %d, %d \n", i, j, subArrays[i][j]);
        }
    }
    free(subArrays);
}
