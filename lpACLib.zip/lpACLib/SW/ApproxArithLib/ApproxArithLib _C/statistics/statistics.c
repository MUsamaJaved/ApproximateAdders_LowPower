/*
Software behavioral models for "lpACLib" (Low-Power Approximate Computing Library).
Copyright (C) 2016, Walaa El-Harouni, Muhammad Shafique, CES, KIT.
E-mail: walaa.elharouny@gmail.com, swahlah@yahoo.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file statistics.c
* @author Walaa El-Harouni
* @brief This file contains functions for statistics generation (quality analysis)
*/

#include "statistics.h"


/**
 *
 * initializes a given array of error entries so that all error values are "999999"
 * with a count of "0"
 *
 * @param  statistics	an array of error entries @see errorEntry
 * @param  size			the size of statistics array
 * @return statistics	 the initialized array of error entries
 */
struct errorEntry* initStatistics(struct errorEntry* statistics, long size) {
	int i;

	for(i = 0; i < size; i++) {
		statistics[i].value = 999999;
		statistics[i].count = 0;
	}
	return statistics;
}

/**
 *
 * updates the given array of error entries with a given error value
 *
 * @param  statistics	an array of error entries @see errorEntry
 * @param  size			the size of statistics array
 * @param  errorValue	the new error value to insert statistics
 * @return statistics	the updated statistics array
 */
struct errorEntry* updateStatistics(struct errorEntry* statistics, long errorValue, long size) {
	int i;

	if(errorValue != 0) {
		for(i = 0; i < size; i++) {
			if(statistics[i].value == errorValue) { // if value is exiting, update the count
				statistics[i].count = statistics[i].count + 1;
				break;
			} else if(statistics[i].value == 999999) { // if non-existing, add an entry with a count of 1
				statistics[i].value = errorValue;
				statistics[i].count = 1;
				break;
			}
		}
	}
	return statistics;
}

/**
 *
 * prints the given array of error entries to a given file
 *
 * @param  statistics	an array of error entries @see errorEntry
 * @param  size			the size of statistics array
 * @param  filename		file to write to
 */
void printStatistics(struct errorEntry* statistics, long size, char* filename) {
	int i;
	int sum = 0;
	long max = 0;

	FILE *fp = NULL;

	fp = fopen(filename, "w");
	if (fp == NULL)
	{
		printf("Error opening file!\n");
		exit(1);
	}

	fprintf(fp, "%s, %s, \n", "Value", "Count");
	for(i = 0; i < size; i++) {
		if(statistics[i].value == 999999) {
			break;
		}
		sum = sum + statistics[i].count;
		if(statistics[i].value > statistics[max].value) {
			max = i;
		}

		fprintf(fp, "%ld, %d, \n", statistics[i].value, statistics[i].count);
	}

	fprintf(fp, "Total error cases = %d \n", sum);
	fprintf(fp, "Max Error = %ld with %d occurrences \n", statistics[max].value, statistics[max].count);

	fclose(fp);
}
